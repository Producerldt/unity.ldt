package ldt1108.com.id4x;
import androidx.appcompat.app.AppCompatActivity;
import com.unity3d.ads.IUnityAdsListener;
import com.unity3d.ads.UnityAds;
import android.os.CountDownTimer;
import android.widget.Button;
import android.graphics.Color;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    private String unityGameID = "XXXXXXX";                 // your ID
    private Boolean testMode = false;                       // on/off test mode
    private String video = "rewardedVideo";
    private Button nut;
    int view = 0;
    private CountDownTimer Dem;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (R.layout.activity_main);
        final UnityAdsListener myAdsListener = new UnityAdsListener ();
        UnityAds.initialize (this, unityGameID, myAdsListener, testMode);
        nut = findViewById(R.id.nutX);
        Start();
    }

    private class UnityAdsListener implements IUnityAdsListener {
        public void onUnityAdsReady (String video) {
            if (view <1) {
                view = view + 1;
                UnityAds.show(MainActivity.this,video);
            }
        }
        @Override
        public void onUnityAdsStart (String video) {
            Stop();
        }
        @Override
        public void onUnityAdsFinish (String video, UnityAds.FinishState finishState) {
            nut.setBackgroundColor(Color.BLACK);
            nut.setText("Finish ♥ Clear application data,change device id and comeback ☻");
        }
        @Override
        public void onUnityAdsError (UnityAds.UnityAdsError error, String message) { }
    }

    public void Start () {
        Dem = new CountDownTimer(60000 , 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                int Time = (int) millisUntilFinished /1000;
                int time = (int) 60 - Time;

                nut.setText("♥ 00:" + time + " ♥");
                if (time < 10) nut.setText("♥ 00:0" + time + " ♥");
                if (time > 59 ) nut.setText("♥ ☻☻☻☻ ♥");
            }

            @Override
            public void onFinish() {
                nut.setBackgroundColor(Color.RED);
                nut.setText("LAG ☻");
            }
        }.start();
    }
    public void Stop () { Dem.cancel(); }
}







